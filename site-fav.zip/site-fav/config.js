// ============================================================
//  CONFIGURAÇÃO DO SITE — é só este arquivo que você mexe.
// ============================================================
window.FAV_CONFIG = {
  // De onde o site lê os valores. Pode ser o dados.json que está junto do site
  // ou o endereço completo de um arquivo atualizado pelo Power Automate
  // (ex.: "https://raw.githubusercontent.com/SEU-USUARIO/SEU-REPO/main/dados.json").
  DATA_URL: "dados.json",

  // De quantos em quantos segundos o site confere se a planilha mudou.
  REFRESH_SECONDS: 60,

  // Senha do modo edição (proteção simples, feita no navegador).
  SENHA_EDICAO: "1234"
};
