# Site de resultados da Filial Florianópolis — FAV Advogados

## O que tem na pasta
- `index.html` — o site (não precisa mexer).
- `dados.json` — **os valores**. É o único arquivo que muda mês a mês.
- `config.js` — endereço dos dados, tempo de atualização e senha de edição.
- `assets/` — logos, ícones e fotos dos consultores (troque a foto sobrescrevendo o arquivo em `assets/fotos/`).

## Como usar
- **Apresentar:** abra o link. Setas do teclado (ou deslize no celular) mudam de slide, **F** abre tela cheia, o seletor no canto escolhe o mês.
- **Editar:** botão **Editar** → senha (`1234`, trocável em `config.js`) → painel lateral com todos os valores, nomes, fotos, novos meses e consultores.
  - O que você muda no painel aparece na hora, mas fica **só naquele navegador**.
  - Para publicar para todos: **Baixar dados.json** e substituir o arquivo no hospedeiro. **Voltar para a planilha** descarta os valores manuais.
- A senha é uma trava simples no navegador (impede mexida sem querer), não é segurança de verdade.

## Publicar (Netlify, o mais simples)
1. Entre em app.netlify.com → **Add new site → Deploy manually**.
2. Arraste a pasta inteira. O link sai na hora.
3. Para atualizar depois, arraste a pasta de novo (ou só troque o `dados.json`).

## Conectar com a planilha (Power Automate)
O site lê o `dados.json` a cada 60 segundos. A ideia é o Power Automate gerar esse arquivo a partir da planilha.

**Antes de tudo, duas limitações:**
1. O conector *Excel Online (Business)* só lê arquivos `.xlsx`, não `.xlsm`. Crie um `.xlsx` no OneDrive/SharePoint com uma aba `SITE` que puxa os totais da planilha de controle por fórmula ou link, formatada como **Tabela**.
2. Gravar o arquivo em um endereço público costuma exigir o conector HTTP, que é Premium. Confira com o TI da FAV se a licença cobre.

**Fluxo sugerido**
1. Gatilho **Recorrência** (a cada 15 min, por exemplo).
2. **Excel Online (Business) → Listar linhas presentes em uma tabela** (a tabela da aba `SITE`).
3. **Compor** o JSON no formato abaixo.
4. **HTTP** com `PUT` na API do GitHub (`/repos/USUARIO/REPO/contents/dados.json`) para gravar o arquivo no repositório.
5. No `config.js`, aponte `DATA_URL` para o endereço raw do arquivo e ligue o site ao repositório (Netlify ou GitHub Pages publicam sozinhos a cada mudança).

**Formato do `dados.json`**
```json
{
  "atualizadoEm": "2026-10-07T10:00:00",
  "meses": {
    "2026-09": {
      "rotulo": "Setembro/26",
      "filial": { "honorarios": 0, "comissao": 0, "tributos": 0, "saldoCredito": 0, "pctCredito": 0 },
      "entradaAnterior": { "rotulo": "Agosto/26", "honorarios": 0, "comissao": 0, "tributos": 0 },
      "consultores": [
        { "nome": "Beatriz", "foto": "assets/fotos/beatriz.jpg", "honorarios": 0, "comissao": 0, "tributos": 0 }
      ]
    }
  }
}
```
`entradaAnterior` é opcional (cria o slide com valores do mês anterior). Valores sempre como número, com ponto decimal.

## Pontos para conferir nos números
- No PowerPoint original, a Beatriz aparecia com honorários e comissão trocados no slide individual; o site usa os valores do gráfico (honorários R$ 170.891,70 e comissão R$ 17.089,17).
- A soma dos consultores não bate com o total da filial (honorários: R$ 467.449,85 contra R$ 464.386,21). O site mostra cada número como está no `dados.json`, sem recalcular.
